package com.contact.contactApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ContactAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
