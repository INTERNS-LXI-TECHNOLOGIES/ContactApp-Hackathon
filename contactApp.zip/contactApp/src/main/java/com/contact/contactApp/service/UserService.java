package com.contact.contactApp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.contact.contactApp.model.UserDomain;
import com.contact.contactApp.repo.UserDomainRepo;
import com.contact.contactApp.repo.UserInfoRepo;
@Service
public class UserService {
    @Autowired
    PasswordEncoder passwordEncoder;
    @Autowired
    UserDomainRepo userDomainRepo;
    @Autowired
    UserInfoRepo userInfoRepo;

    public UserDomain createUser(UserDomain user){
        //userInfoRepo.save(user.getUserInfo());
        return userDomainRepo.save(user);
    }
}
