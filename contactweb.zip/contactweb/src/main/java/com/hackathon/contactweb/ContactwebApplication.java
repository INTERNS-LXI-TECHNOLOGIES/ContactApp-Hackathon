package com.hackathon.contactweb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ContactwebApplication {

	public static void main(String[] args) {
		SpringApplication.run(ContactwebApplication.class, args);
	}

}
