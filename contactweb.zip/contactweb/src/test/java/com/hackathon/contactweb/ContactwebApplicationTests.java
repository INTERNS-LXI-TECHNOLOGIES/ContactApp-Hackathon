package com.hackathon.contactweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ContactwebApplicationTests {

	@Test
	void contextLoads() {
	}

}
